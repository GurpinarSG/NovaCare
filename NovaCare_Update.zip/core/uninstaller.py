"""
NovaCare System Suite - Software Uninstaller & Deep Leftover Cleaner
Lists installed software, runs standard/silent uninstallers, and scans
file system and registry for residual leftovers.
"""
import os
import winreg
import subprocess
import shlex
from dataclasses import dataclass, field
from typing import Optional
from core.utils import format_bytes, safe_remove_directory, safe_remove_file

@dataclass
class InstalledApp:
    id: str
    name: str
    version: str
    publisher: str
    install_date: str
    size_bytes: int
    uninstall_string: str
    quiet_uninstall_string: str
    install_location: str
    icon_path: str
    registry_path: str
    root_name: str

@dataclass
class LeftoverItem:
    item_type: str   # "file", "folder", "registry"
    path: str
    details: str
    selected: bool = True

class AppUninstaller:
    def __init__(self):
        self.apps: list[InstalledApp] = []

    def scan_installed_apps(self) -> list[InstalledApp]:
        self.apps.clear()
        targets = [
            ("HKLM", r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
            ("HKLM", r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Uninstall")
        ]

        seen_names = set()

        for root_name, sub in targets:
            root = winreg.HKEY_LOCAL_MACHINE if root_name == "HKLM" else winreg.HKEY_CURRENT_USER
            try:
                with winreg.OpenKey(root, sub, 0, winreg.KEY_READ) as base_key:
                    sub_count, _, _ = winreg.QueryInfoKey(base_key)
                    for i in range(sub_count):
                        try:
                            app_sub = winreg.EnumKey(base_key, i)
                            full_sub = f"{sub}\\{app_sub}"
                            with winreg.OpenKey(root, full_sub, 0, winreg.KEY_READ) as app_key:
                                def get_val(name: str, default="") -> str:
                                    try:
                                        val, _ = winreg.QueryValueEx(app_key, name)
                                        return str(val).strip()
                                    except OSError:
                                        return default

                                name = get_val("DisplayName")
                                if not name:
                                    continue

                                # Ignore system components or windows updates if SystemComponent == 1
                                try:
                                    sc, _ = winreg.QueryValueEx(app_key, "SystemComponent")
                                    if sc == 1:
                                        continue
                                except OSError:
                                    pass

                                # Avoid duplicate names
                                norm_name = name.strip().lower()
                                if norm_name in seen_names:
                                    continue
                                seen_names.add(norm_name)

                                version = get_val("DisplayVersion", "1.0")
                                publisher = get_val("Publisher", "Bilinmiyor")
                                inst_date = get_val("InstallDate", "")
                                if len(inst_date) == 8 and inst_date.isdigit():
                                    inst_date = f"{inst_date[:4]}-{inst_date[4:6]}-{inst_date[6:]}"

                                size_kb = 0
                                try:
                                    sz_val, _ = winreg.QueryValueEx(app_key, "EstimatedSize")
                                    size_kb = int(sz_val)
                                except (OSError, ValueError):
                                    pass

                                uninst_str = get_val("UninstallString")
                                quiet_uninst = get_val("QuietUninstallString")
                                inst_loc = get_val("InstallLocation")
                                icon_p = get_val("DisplayIcon")

                                self.apps.append(InstalledApp(
                                    id=f"{root_name}_{app_sub}",
                                    name=name,
                                    version=version,
                                    publisher=publisher,
                                    install_date=inst_date,
                                    size_bytes=size_kb * 1024,
                                    uninstall_string=uninst_str,
                                    quiet_uninstall_string=quiet_uninst,
                                    install_location=inst_loc,
                                    icon_path=icon_p,
                                    registry_path=full_sub,
                                    root_name=root_name
                                ))
                        except OSError:
                            continue
            except OSError:
                continue

        # Sort alphabetically by name
        self.apps.sort(key=lambda a: a.name.lower())
        return self.apps

    def launch_uninstaller(self, app: InstalledApp, quiet: bool = False) -> subprocess.Popen:
        """Launches the standard or quiet uninstaller in background."""
        cmd = app.quiet_uninstall_string if (quiet and app.quiet_uninstall_string) else app.uninstall_string
        if not cmd:
            raise ValueError("Kaldırma komutu mevcut değil.")

        expanded = os.path.expandvars(cmd)
        # Windows command runner
        return subprocess.Popen(expanded, shell=True)

    def scan_leftovers(self, app: InstalledApp) -> list[LeftoverItem]:
        """Scans filesystem and registry for remnants related to this app."""
        leftovers: list[LeftoverItem] = []
        app_name_parts = [p.lower() for p in app.name.split() if len(p) >= 3 and p.lower() not in ('microsoft', 'windows', 'the', 'for', 'corporation', 'setup', 'edition', 'suite')]
        if not app_name_parts:
            app_name_parts = [app.name.lower()]

        # 1. Check InstallLocation
        if app.install_location and os.path.exists(app.install_location):
            leftovers.append(LeftoverItem(
                item_type="folder",
                path=app.install_location,
                details=f"Kurulum Klasörü ({app.install_location})"
            ))

        # 2. Check standard program directories
        dirs_to_check = [
            os.environ.get('PROGRAMFILES', r'C:\Program Files'),
            os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'),
            os.environ.get('APPDATA', ''),
            os.environ.get('LOCALAPPDATA', ''),
            os.environ.get('ALLUSERSPROFILE', r'C:\ProgramData')
        ]

        for base_dir in dirs_to_check:
            if not base_dir or not os.path.exists(base_dir):
                continue
            try:
                for entry in os.scandir(base_dir):
                    if entry.is_dir():
                        dname = entry.name.lower()
                        # Match if matches app's prominent words
                        if any(part in dname for part in app_name_parts):
                            # Avoid false positives with common system folders
                            if dname not in ('system32', 'syswow64', 'common files', 'microsoft', 'windows'):
                                leftovers.append(LeftoverItem(
                                    item_type="folder",
                                    path=entry.path,
                                    details=f"Kalan Uygulama Verisi ({entry.name})"
                                ))
            except (PermissionError, OSError):
                continue

        # 3. Check registry software keys
        for root, rname in [(winreg.HKEY_CURRENT_USER, "HKCU"), (winreg.HKEY_LOCAL_MACHINE, "HKLM")]:
            soft_path = r"Software"
            try:
                with winreg.OpenKey(root, soft_path, 0, winreg.KEY_READ) as k:
                    count, _, _ = winreg.QueryInfoKey(k)
                    for i in range(count):
                        try:
                            sub_k = winreg.EnumKey(k, i)
                            if any(part in sub_k.lower() for part in app_name_parts):
                                if sub_k.lower() not in ('microsoft', 'classes', 'registeredapplications', 'policies'):
                                    leftovers.append(LeftoverItem(
                                        item_type="registry",
                                        path=f"{rname}\\Software\\{sub_k}",
                                        details="Kayıt Defteri Anahtarı"
                                    ))
                        except OSError:
                            continue
            except OSError:
                pass

        return leftovers

    def clean_leftovers(self, leftovers: list[LeftoverItem]) -> tuple[int, int]:
        """Cleans checked leftovers. Returns (cleaned_count, failed_count)."""
        cleaned = 0
        failed = 0
        for item in leftovers:
            if not item.selected:
                continue
            try:
                if item.item_type == "folder":
                    if safe_remove_directory(item.path):
                        cleaned += 1
                    else:
                        failed += 1
                elif item.item_type == "file":
                    if safe_remove_file(item.path):
                        cleaned += 1
                    else:
                        failed += 1
                elif item.item_type == "registry":
                    parts = item.path.split('\\', 1)
                    if len(parts) == 2:
                        rname, sub = parts
                        root = winreg.HKEY_CURRENT_USER if rname == "HKCU" else winreg.HKEY_LOCAL_MACHINE
                        # Delete subkey tree safely
                        try:
                            winreg.DeleteKey(root, sub)
                            cleaned += 1
                        except OSError:
                            failed += 1
            except Exception:
                failed += 1

        return cleaned, failed
