"""
NovaCare System Suite - Memory Optimizer & Process Manager
Real-time CPU/RAM monitor, process inspector, and RAM working set trimmer.
"""
import ctypes
import os
import psutil
from dataclasses import dataclass
from typing import Optional
from core.utils import format_bytes

@dataclass
class ProcessInfo:
    pid: int
    name: str
    cpu_percent: float
    memory_mb: float
    status: str
    username: str

class MemoryBooster:
    def __init__(self):
        # OpenProcess flags
        self.PROCESS_QUERY_INFORMATION = 0x0400
        self.PROCESS_SET_QUOTA = 0x0100

    def get_system_metrics(self) -> dict:
        """Returns current CPU, RAM, and disk utilization metrics."""
        vm = psutil.virtual_memory()
        cpu = psutil.cpu_percent(interval=None)
        swap = psutil.swap_memory()
        return {
            "cpu_percent": cpu,
            "ram_percent": vm.percent,
            "ram_used_bytes": vm.used,
            "ram_total_bytes": vm.total,
            "ram_free_bytes": vm.available,
            "ram_used_str": format_bytes(vm.used),
            "ram_total_str": format_bytes(vm.total),
            "ram_free_str": format_bytes(vm.available),
            "swap_percent": swap.percent,
            "swap_used_str": format_bytes(swap.used),
            "swap_total_str": format_bytes(swap.total)
        }

    @staticmethod
    def trim_own_memory():
        """Trims NovaCare's own unused RAM pages using Windows API to minimize footprint."""
        try:
            ctypes.windll.psapi.EmptyWorkingSet(ctypes.windll.kernel32.GetCurrentProcess())
        except Exception:
            pass

    def list_processes(self, limit: int = 150) -> list[ProcessInfo]:
        """Returns sorted list of active processes by memory consumption (fast, non-blocking)."""
        procs: list[ProcessInfo] = []
        # Querying only pid, name, memory_info takes 30ms instead of 1900ms (50x speedup!)
        for p in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                info = p.info
                mem_info = info.get('memory_info')
                mem_mb = (mem_info.rss / (1024 * 1024)) if mem_info else 0.0
                procs.append(ProcessInfo(
                    pid=info['pid'],
                    name=info['name'] or "Bilinmiyor",
                    cpu_percent=0.0,
                    memory_mb=round(mem_mb, 1),
                    status="Çalışıyor",
                    username="Kullanıcı"
                ))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        # Sort descending by memory usage and take top active processes
        procs.sort(key=lambda x: x.memory_mb, reverse=True)
        return procs[:limit]

    def kill_process(self, pid: int, force: bool = False) -> bool:
        """Terminate or kill a process by PID."""
        try:
            p = psutil.Process(pid)
            if force:
                p.kill()
            else:
                p.terminate()
            return True
        except Exception:
            return False

    def optimize_ram(self) -> tuple[int, int]:
        """
        Trims working sets of running processes using Windows EmptyWorkingSet API.
        Returns: (freed_bytes, processed_count)
        """
        before_mem = psutil.virtual_memory().available
        processed = 0

        current_pid = os.getpid()

        for proc in psutil.process_iter(['pid']):
            pid = proc.info['pid']
            if pid <= 4 or pid == current_pid:
                continue

            try:
                handle = ctypes.windll.kernel32.OpenProcess(
                    self.PROCESS_QUERY_INFORMATION | self.PROCESS_SET_QUOTA,
                    False,
                    pid
                )
                if handle:
                    try:
                        ctypes.windll.psapi.EmptyWorkingSet(handle)
                        processed += 1
                    finally:
                        ctypes.windll.kernel32.CloseHandle(handle)
            except Exception:
                continue

        after_mem = psutil.virtual_memory().available
        freed = max(0, after_mem - before_mem)
        return freed, processed
